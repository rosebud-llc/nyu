#ifndef INCLUDED_SCHEDULER_HEADER
#define INCLUDED_SCHEDULER_HEADER

class Scheduler:
{

public:
	//void add_process(Process *p);
	//Process* get_next_process();
	//bool does_preempt(); // returns true for 'E' schedules, else false.
};

#endif
