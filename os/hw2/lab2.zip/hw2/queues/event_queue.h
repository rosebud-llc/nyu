#ifndef INCLUDED_EVENT_QUEUE
#define INCLUDED_EVENT_QUEUE

class EventQueue(BaseQueue)
{

public:
	//
	//

};

#endif
