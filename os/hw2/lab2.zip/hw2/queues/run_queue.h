#ifndef INCLUDED_RUN_QUEUE
#define INCLUDED_RUN_QUEUE

class RunQueue(BaseQueue)
{

public:
	//
	//

};

#endif
