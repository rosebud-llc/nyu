#ifndef INCLUDED_BASE_QUEUE_HEADER
#define INCLUDED_BASE_QUEUE_HEADER


class BaseQueue:
{

public: 
	//
	//
};

#endif
